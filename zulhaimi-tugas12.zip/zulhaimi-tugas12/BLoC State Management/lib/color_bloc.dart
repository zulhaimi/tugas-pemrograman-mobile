import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';

enum ColorEvent {to_yellow_accent, to_black87}

class ColorBloc extends Bloc<ColorEvent, Color> {
  Color _color = Colors.yellowAccent;

  @override
  Color get initialState => Colors.yellowAccent;

  @override
  Stream<Color> mapEventToState(ColorEvent event) async* {
   _color = (event == ColorEvent.to_yellow_accent) ? Colors.yellowAccent : Colors.black87;
   yield _color;
  }
}