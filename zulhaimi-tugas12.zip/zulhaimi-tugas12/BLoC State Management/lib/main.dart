import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'color_bloc.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: BlocProvider<ColorBloc>(
          builder: (context) => ColorBloc(),
          child: MainPage()),
    );
  }
}

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    ColorBloc bloc = BlocProvider.of<ColorBloc>(context);
    return Scaffold(
      floatingActionButton: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: <Widget>[
          FloatingActionButton(backgroundColor: Colors.yellowAccent, onPressed: (){
            bloc.dispatch(ColorEvent.to_yellow_accent);
          },),
          SizedBox(width: 20,),
          FloatingActionButton(backgroundColor: Colors.black87, onPressed: (){
            bloc.dispatch(ColorEvent.to_black87);
          },)
        ],
      ),
      appBar: AppBar(title:  Text("BLoC Package Zulhaimi12"),),
      body: Center(
        child: BlocBuilder<ColorBloc, Color>(
          builder: (context, currentColor) => AnimatedContainer(
            width: 120,
            height: 120,
            color: currentColor,
            duration: Duration(milliseconds: 800),
          ),
        ),
      ),
    );
  }
}