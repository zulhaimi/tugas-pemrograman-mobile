import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:zulhaimi12/color_bloc.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  ColorBloc bloc = ColorBloc();

  @override
    void dispose() {
   bloc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {

    return MaterialApp(
      home: Scaffold(
        floatingActionButton: Row (
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: <Widget>[
            FloatingActionButton(
              backgroundColor: Colors.blueGrey,
              onPressed: () {
                bloc.eventSink.add(ColorEvent.to_blue_grey);
              },),
            SizedBox(width: 12,),
            FloatingActionButton(onPressed: () {
              bloc.eventSink.add(ColorEvent.to_red);
            },
            backgroundColor: Colors.red,
            )
          ],
        ),
        appBar: AppBar(title: Text("BLoC Cont&Stream Zulhaimi"),),
        body: Center(
          child: StreamBuilder(
            stream: bloc.stateStream,
            initialData: Colors.blueGrey,
            builder: (context, snapshot) {
              return AnimatedContainer(
                duration: Duration(milliseconds: 800),
                width: 140,
                height: 140,
                color: snapshot.data,
              );
            },
          ),
        ),
      ),
    );
  }
}