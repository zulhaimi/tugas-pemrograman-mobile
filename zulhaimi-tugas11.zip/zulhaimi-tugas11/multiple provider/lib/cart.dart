import 'package:flutter/foundation.dart';

class Cart with ChangeNotifier{
  int _banyak = 0;

  int get banyak => _banyak;
  set banyak(int value) {
    _banyak = value;
    notifyListeners();
  }
}