import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:zulhaimi11/cart.dart';
import 'package:zulhaimi11/money.dart';

void main() => runApp(MyApp());


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
    home: MultiProvider(
      providers: [
        ChangeNotifierProvider<Money>(create: (context) => Money(),),
        ChangeNotifierProvider<Cart>(create: (context) => Cart(),)
      ],
      child: Scaffold(
        floatingActionButton: Consumer<Money>(
          builder:(context, money, _) => Consumer<Cart>(
            builder: (context, cart, _) => FloatingActionButton(
              onPressed: () {
                if (money.balance >= 100) {
                  cart.banyak += 1;
                  money.balance -= 100;
                }
              },
              child: Icon(Icons.add_shopping_cart),
              backgroundColor: Colors.black54,
            ),
          ),
        ),
        appBar: AppBar(backgroundColor: Colors.black54, title: Text("Multi Provider Zulhaimi"),),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
              Text("Balance"),
              Container(
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Consumer<Money>(
                    builder: (context, money, _) => Text(
                      money.balance.toString(),
                      style: TextStyle(
                          color: Colors.black54, fontWeight: FontWeight.w800),
                    ),
                  ),
                ),
                height: 40,
                width: 160,
                margin: EdgeInsets.all(4),
                padding: EdgeInsets.all(4),
                decoration: BoxDecoration(
                    color: Colors.black54,
                    border: Border.all(color: Colors.black54, width: 4)),
              )
            ],
          ),
              Container(
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Consumer<Cart>(
                    builder: (context, cart, _) => Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(
                          "Kelereng (100) x " + cart.banyak.toString(),
                          style: TextStyle(
                              color: Colors.black, fontWeight: FontWeight.w400),
                        ),
                    Text(
                      (100 * cart.banyak).toString(),
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.w400),
                ),
                      ],
                    ),
                  ),
                ),
                height: 40,
                margin: EdgeInsets.all(4),
                padding: EdgeInsets.all(4),
                decoration: BoxDecoration(
                    border: Border.all(color: Colors.red, width: 4)),
              )
              ],
        ),
      ),
      ),
    ),
    );
        }
}
