import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class ApplicationColor with ChangeNotifier{
  bool _abuabu = true;

  bool get abuabu => _abuabu;
  set abuabu(bool value)
  {
    _abuabu = value;
    notifyListeners();
  }

  Color get color => (_abuabu) ? Colors.grey : Colors.orange;
}