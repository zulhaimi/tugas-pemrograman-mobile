import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:zulhaimii11/application_color.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: ChangeNotifierProvider<ApplicationColor>(
        create: (BuildContext context) => ApplicationColor(),
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: Colors.black,
            title: Consumer<ApplicationColor>(
              builder: (context, applicationColor, _) => Text(
                "Single Provider Zulhaimi",
                style: TextStyle(color: applicationColor.color),
              ),
            ),
          ),
          body: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Consumer<ApplicationColor>(
                  builder: (context, applicationColor, _) => AnimatedContainer(
                    margin: EdgeInsets.all(4),
                    width: 80,
                    height: 80,
                    color: applicationColor.color,
                    duration: Duration(milliseconds: 400),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(margin: EdgeInsets.all(4), child: Text("A")),
                    Consumer<ApplicationColor>(
                        builder: (context, applicationColor, _) => Switch(
                          value: applicationColor.abuabu,
                          onChanged: (newValue){
                            applicationColor.abuabu = newValue;
                            },
                        ),
                    ),
                    Container(margin: EdgeInsets.all(4), child: Text("B"))

                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
