import 'package:hive/hive.dart';

part 'keluarga.g.dart';

@HiveType()
class Keluarga {
  @HiveField(0)
  String name;
  @HiveField(1)
  int umur;
  Keluarga(this.name, this.umur);
}