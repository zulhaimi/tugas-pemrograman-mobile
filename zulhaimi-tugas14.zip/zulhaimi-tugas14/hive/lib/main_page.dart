import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:zulhaimi14/model/keluarga.dart';

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Hive Zulhaimi 14"),),
      body: FutureBuilder(
        future: Hive.openBox("keluargaz"),
        builder: (context, snapshot) {
          if(snapshot.connectionState == ConnectionState.done)
            {
              if(snapshot.hasError)
                return Center(child: Text(snapshot.error),);
              else {
                var keluargazBox = Hive.box("keluargaz");
                if (keluargazBox.length == 0)
                  {
                    keluargazBox.add(Keluarga("Rafasya", 1));
                    keluargazBox.add(Keluarga("Dhia", 8));
                  }
                return WatchBoxBuilder(
                  box: keluargazBox,
                  builder: (context, keluargaz) => Container(
                    margin: EdgeInsets.all(40),
                    child: ListView.builder(
                      itemCount: keluargaz.length,
                      itemBuilder: (context, index) {
                        Keluarga keluarga = keluargaz.getAt(index);
                        return Container(
                          padding: EdgeInsets.all(20),
                          margin: EdgeInsets.only(bottom: 20),
                        decoration:
                          BoxDecoration(color: Colors.yellow, boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.4),
                              offset: Offset(4, 4),
                              blurRadius: 4)
                          ]),
                        child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Text(keluarga.name +
                              " [ " +
                              keluarga.umur.toString() + "]"),
                          Row(children: <Widget>[
                            IconButton(
                                icon: Icon(Icons.trending_up),
                                color: Colors.orange,
                                onPressed: () {
                                  keluargaz.putAt(
                                      index,
                                      Keluarga(
                                        keluarga.name, keluarga.umur + 1));
                                },
                            ),
                        IconButton(
                        icon: Icon(Icons.content_copy),
                        color: Colors.blue,
                        onPressed: () {
                          keluargaz.add(Keluarga(keluarga.name, keluarga.umur));
                        },
                        ),
                        IconButton(
                        icon: Icon(Icons.delete),
                        color: Colors.red,
                        onPressed: () {
                          keluargaz.deleteAt(index);
                        },
                        )
                          ],
                          )
                        ],
                        ),
                        );
                      },
                    ),
                  ),
                );
                }
            } else
            return Center(
              child: CircularProgressIndicator(),
            );
        },
      )
    );
  }
}