class Customer{
  String nama;
  int umur;

  int get age => umur;
  set age(int value){
    if(value < 0){
      value *= -1;
    }
    umur = value;
  }
  Customer(){
    nama = "Dhia";
    umur =0;
    }
  }
