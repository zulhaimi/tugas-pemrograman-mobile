import 'package:flutter_test/flutter_test.dart';
import 'package:zulhaimii14/Customer.dart';


void main() {
  Customer p;
  p = Customer();

  test("Test Unit Nama", () {
    expect(p.nama, equals("Dhiaaaa"));
  }
  );
  test("Test Unit Umur", () {
    p.umur = -8;
    expect(p.umur, isPositive);
  }
  );
}

